// pages/scrollnav/scrollnav.js
Page({
  data: {
    navList: ['今日特惠', '烟灶推荐', '净水饮水推荐', '洗碗机推荐', '电热推荐', '燃热推荐', '消毒柜推荐', '嵌入式推荐', '商用电器','活动说明'],
    status: 0,

  
      left: false ,
      right: false,
      activeIndex: 0
      
  },
  getStatus(e){
    this.setData({ status: e.currentTarget.dataset.index})
  },
  cccccc(event){
    console.log(event)
  },
  changeswiper: function(e) {
    console.log( e.detail)
    var index = e.detail.current;//当前所在页面的 index
    console.log(e)
    if(index > this.data.activeIndex) {//左滑事件判断
     this.setData({
     left: true,//若为左滑，left值为true,触发图片动画效果
     activeIndex:index
     })
    } else if(index < this.data.activeIndex) {//右滑事件判断
     this.setData({
     right: true,//若为右滑，right值为true,触发图片动画效果
     activeIndex:index
     })
    }
    setTimeout(() => {//每滑动一次，数据发生变化
    //  this.setData({
    //  activeIndex: index,
    //  left:false,
    //  right:false
    //  })
    }, 1000);
    },
})